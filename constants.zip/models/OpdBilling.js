const mongoose = require("mongoose");

const opdBillingServiceSchema = new mongoose.Schema({
  serviceId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Service',
    required: true
  },
  serviceName: {
    type: String,
    required: true,
    trim: true
  },
  serviceCode: {
    type: String,
    required: true,
    trim: true
  },
  rate: {
    type: Number,
    required: true,
    min: 0
  },
  quantity: {
    type: Number,
    required: true,
    min: 1,
    default: 1
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  }
}, { _id: false });

const opdBillingSchema = new mongoose.Schema(
  {
    billId: {
      type: String,
      unique: true
    },
    patientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true
    },
    patientInfo: {
      uhid: {
        type: String,
        required: true,
        trim: true
      },
      name: {
        type: String,
        required: true,
        trim: true
      },
      fatherOrHusbandName: {
        type: String,
        required: true,
        trim: true
      },
      mobileNo: {
        type: String,
        required: true,
        trim: true
      },
      age: {
        type: String,
        required: true,
        trim: true
      },
      gender: {
        type: String,
        required: true,
        enum: ['Male', 'Female', 'Other']
      }
    },
    patientCategory: {
      type: String,
      required: true,
      trim: true
    },
    refby: {
      type: String,
      required: true,
      trim: true
    },
    consultantDoctor: {
      type: String,
      required: true,
      trim: true
    },
    priority: {
      type: String,
      required: true,
      trim: true
    },
    paymentMode: {
      type: String,
      required: true,
      trim: true
    },
    paidAmount: {
      type: Number,
      required: true,
      min: 0,
      default: 0
    },
    services: [opdBillingServiceSchema],
    billing: {
      grandTotal: {
        type: Number,
        required: true,
        min: 0
      },
      discountPercent: {
        type: Number,
        min: 0,
        max: 100,
        default: 0
      },
      discountValue: {
        type: Number,
        min: 0,
        default: 0
      },
      paidAmount: {
        type: Number,
        required: true,
        min: 0
      },
      balanceAmount: {
        type: Number,
        default: 0
      }
    },
    status: {
      type: String,
      enum: ['pending', 'paid', 'partial', 'cancelled'],
      default: 'pending'
    },
    billDate: {
      type: Date,
      default: Date.now
    }
  },
  { timestamps: true }
);

// Pre-save middleware to generate Bill ID and calculate amounts
opdBillingSchema.pre("save", async function (next) {
  console.log(`[PRE-SAVE] OPD Bill pre-save triggered for: ${this.billId || 'NEW'}`);
  // Mark if this is a new document for pathology creation
  this._wasNew = this.isNew;
  
  // Generate Bill ID if not provided
  if (!this.billId) {
    const currentYear = new Date().getFullYear();
    const currentMonth = String(new Date().getMonth() + 1).padStart(2, "0");
    const currentDay = String(new Date().getDate()).padStart(2, "0");
    
    // Find the last bill created today to get next sequence number
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const lastBill = await this.constructor.findOne({
      createdAt: { $gte: today, $lt: tomorrow }
    }).sort({ createdAt: -1 });
    
    let sequenceNumber = 1;
    if (lastBill && lastBill.billId) {
      const lastSequence = parseInt(lastBill.billId.slice(-4));
      sequenceNumber = lastSequence + 1;
    }
    
    this.billId = `OPD${currentYear}${currentMonth}${currentDay}${String(sequenceNumber).padStart(4, '0')}`;
  }

  // Validate service amounts
  if (this.services && this.services.length > 0) {
    for (const service of this.services) {
      const expectedAmount = service.rate * service.quantity;
      if (service.amount !== expectedAmount) {
        service.amount = expectedAmount;
      }
    }

    // Calculate grand total from services
    const calculatedTotal = this.services.reduce((total, service) => total + service.amount, 0);
    
    // Apply discount
    const discountAmount = this.billing.discountPercent 
      ? (calculatedTotal * this.billing.discountPercent) / 100 
      : this.billing.discountValue || 0;
    
    this.billing.discountValue = discountAmount;
    this.billing.grandTotal = calculatedTotal - discountAmount;
    this.billing.balanceAmount = this.billing.grandTotal - this.billing.paidAmount;
    
    // Update payment status
    if (this.billing.balanceAmount <= 0) {
      this.status = 'paid';
    } else if (this.billing.paidAmount > 0) {
      this.status = 'partial';
    } else {
      this.status = 'pending';
    }
  }

  next();
});

// Function to create lab orders for laboratory/pathology services
async function createLabOrdersForBill(billDocument) {
  console.log(`[LAB ORDER FUNCTION] Starting lab order creation for bill ${billDocument.billId}`);
  console.log(`[LAB ORDER FUNCTION] Services in bill:`, billDocument.services);
  
  try {
    const Service = require('./Service');
    const LabOrder = require('./LabOrder');
    const LabOrderTest = require('./LabOrderTest');
    
    // Get full service details to check categories
    const serviceIds = billDocument.services.map(s => s.serviceId);
    console.log(`[LAB ORDER FUNCTION] Service IDs:`, serviceIds);
    
    const services = await Service.find({ _id: { $in: serviceIds } });
    console.log(`[LAB ORDER FUNCTION] Found services:`, services.map(s => ({ name: s.name, category: s.category })));
    
    // Filter laboratory and pathology services
    const labServices = services.filter(service => 
      service.category === 'laboratory' || service.category === 'pathology'
    );
    console.log(`[LAB ORDER FUNCTION] Lab/Pathology services found:`, labServices.length);
    
    if (labServices.length > 0) {
      console.log(`[${new Date().toISOString()}] Creating lab order for bill: ${billDocument.billId}`);
      
      // Create a single lab order for all laboratory services
      const labOrderData = {
        patientId: billDocument.patientId,
        visitId: billDocument.billId, // Using billId as visitId for now
        opdBillingId: billDocument._id,
        doctorId: billDocument.patientId, // Using patientId temporarily, should be actual doctor ID
        priority: billDocument.priority.toLowerCase() === 'urgent' ? 'urgent' : 'normal',
        instructions: `Laboratory tests ordered via OPD billing ${billDocument.billId}`,
        patientInfo: {
          name: billDocument.patientInfo.name,
          uhid: billDocument.patientInfo.uhid,
          age: billDocument.patientInfo.age,
          gender: billDocument.patientInfo.gender,
          mobileNo: billDocument.patientInfo.mobileNo
        },
        doctorInfo: {
          name: billDocument.consultantDoctor,
          specialization: ''
        }
      };
      
      console.log(`[LAB ORDER FUNCTION] Creating lab order with data:`, labOrderData);
      const labOrder = new LabOrder(labOrderData);
      await labOrder.save();
      console.log(`[LAB ORDER FUNCTION] Lab order created: ${labOrder.accessionNo}`);
      
      // Create lab order tests for each laboratory service
      const labOrderTests = [];
      
      for (const service of labServices) {
        // Find the corresponding billing service data
        const billingService = billDocument.services.find(s => s.serviceId.toString() === service._id.toString());
        console.log(`[LAB ORDER FUNCTION] Processing service: ${service.name}, billing service found:`, !!billingService);
        
        if (billingService) {
          // Create lab order test for each quantity
          for (let i = 0; i < billingService.quantity; i++) {
            const labOrderTestData = {
              labOrderId: labOrder._id,
              serviceId: service._id,
              serviceInfo: {
                name: service.name,
                code: service.code,
                category: service.category
              },
              status: 'pending'
            };
            
            console.log(`[LAB ORDER FUNCTION] Creating lab order test:`, labOrderTestData);
            const labOrderTest = new LabOrderTest(labOrderTestData);
            await labOrderTest.save();
            labOrderTests.push(labOrderTest);
            console.log(`[LAB ORDER FUNCTION] Lab order test created: ${labOrderTest._id}`);
          }
        }
      }
      
      console.log(`[${new Date().toISOString()}] Successfully created lab order ${labOrder.accessionNo} with ${labOrderTests.length} tests for bill: ${billDocument.billId}`);
      return { labOrder, labOrderTests };
    } else {
      console.log(`[LAB ORDER FUNCTION] No lab/pathology services found in bill ${billDocument.billId}`);
    }
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Error creating lab orders for bill ${billDocument.billId}:`, error);
    throw error;
  }
}

// Post-save middleware to auto-create lab orders for laboratory services
opdBillingSchema.post("save", async function (doc) {
  console.log(`[LAB ORDER MIDDLEWARE] Post-save middleware triggered for bill ${doc.billId}!`);
  try {
    // Only process if this is a new document (not an update)
    if (doc._wasNew) {
      await createLabOrdersForBill(doc);
    }
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Error in post-save middleware for bill ${doc.billId}:`, error);
    // Don't fail the billing operation if lab order creation fails
  }
});

// Export the function for manual calling
opdBillingSchema.statics.createLabOrders = createLabOrdersForBill;

// Indexes for better performance
opdBillingSchema.index({ patientId: 1 });
opdBillingSchema.index({ billDate: 1 });
opdBillingSchema.index({ status: 1 });
opdBillingSchema.index({ billId: 1 });
opdBillingSchema.index({ 'patientInfo.uhid': 1 });

module.exports = mongoose.model("OpdBilling", opdBillingSchema);