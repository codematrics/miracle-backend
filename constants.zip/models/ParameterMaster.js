const mongoose = require("mongoose");

const parameterMasterSchema = new mongoose.Schema(
  {
    serviceId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Service',
      required: true,
      index: true
    },
    parameterName: {
      type: String,
      required: true,
      trim: true,
      maxlength: [200, 'Parameter name must not exceed 200 characters']
    },
    parameterCode: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      maxlength: [20, 'Parameter code must not exceed 20 characters']
    },
    unit: {
      type: String,
      required: true,
      trim: true,
      maxlength: [50, 'Unit must not exceed 50 characters']
    },
    referenceRange: {
      type: String,
      required: true,
      trim: true,
      maxlength: [200, 'Reference range must not exceed 200 characters']
    },
    // Gender-specific ranges
    maleRange: {
      type: String,
      trim: true,
      maxlength: [200, 'Male range must not exceed 200 characters']
    },
    femaleRange: {
      type: String,
      trim: true,
      maxlength: [200, 'Female range must not exceed 200 characters']
    },
    // Age-specific ranges
    childRange: {
      type: String,
      trim: true,
      maxlength: [200, 'Child range must not exceed 200 characters']
    },
    adultRange: {
      type: String,
      trim: true,
      maxlength: [200, 'Adult range must not exceed 200 characters']
    },
    // Parameter metadata
    dataType: {
      type: String,
      enum: ['numeric', 'text', 'boolean', 'select'],
      default: 'numeric'
    },
    selectOptions: [{
      value: String,
      label: String
    }],
    sortOrder: {
      type: Number,
      default: 0
    },
    isActive: {
      type: Boolean,
      default: true
    },
    // Validation rules
    minValue: {
      type: Number
    },
    maxValue: {
      type: Number
    },
    decimalPlaces: {
      type: Number,
      default: 2
    },
    // Critical values
    criticalLow: {
      type: Number
    },
    criticalHigh: {
      type: Number
    },
    // Display settings
    printOnReport: {
      type: Boolean,
      default: true
    },
    formula: {
      type: String,
      trim: true,
      maxlength: [500, 'Formula must not exceed 500 characters']
    },
    // Method and machine info
    methodology: {
      type: String,
      trim: true,
      maxlength: [200, 'Methodology must not exceed 200 characters']
    },
    instrumentUsed: {
      type: String,
      trim: true,
      maxlength: [100, 'Instrument must not exceed 100 characters']
    }
  },
  { 
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Virtual for display name with unit
parameterMasterSchema.virtual('displayName').get(function() {
  return `${this.parameterName} (${this.unit})`;
});

// Method for appropriate reference range based on gender/age
parameterMasterSchema.methods.getRange = function(gender, age) {
  // Priority: gender-specific > age-specific > default
  if (gender === 'Male' && this.maleRange) return this.maleRange;
  if (gender === 'Female' && this.femaleRange) return this.femaleRange;
  
  if (age < 18 && this.childRange) return this.childRange;
  if (age >= 18 && this.adultRange) return this.adultRange;
  
  return this.referenceRange;
};

// Method to check if value is critical
parameterMasterSchema.methods.isCriticalValue = function(value) {
  if (this.dataType !== 'numeric') return false;
  const numValue = parseFloat(value);
  if (isNaN(numValue)) return false;
  
  return (this.criticalLow && numValue < this.criticalLow) || 
         (this.criticalHigh && numValue > this.criticalHigh);
};

// Method to validate value
parameterMasterSchema.methods.validateValue = function(value) {
  const errors = [];
  
  if (this.dataType === 'numeric') {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) {
      errors.push('Value must be numeric');
    } else {
      if (this.minValue !== undefined && numValue < this.minValue) {
        errors.push(`Value must be at least ${this.minValue}`);
      }
      if (this.maxValue !== undefined && numValue > this.maxValue) {
        errors.push(`Value must not exceed ${this.maxValue}`);
      }
    }
  }
  
  if (this.dataType === 'select') {
    const validOptions = this.selectOptions.map(opt => opt.value);
    if (validOptions.length > 0 && !validOptions.includes(value)) {
      errors.push(`Value must be one of: ${validOptions.join(', ')}`);
    }
  }
  
  return errors;
};

// Indexes for better performance
parameterMasterSchema.index({ serviceId: 1, sortOrder: 1 });
parameterMasterSchema.index({ parameterCode: 1 });
parameterMasterSchema.index({ isActive: 1 });
parameterMasterSchema.index({ serviceId: 1, isActive: 1, sortOrder: 1 });

// Compound unique index for parameter within service
parameterMasterSchema.index({ serviceId: 1, parameterCode: 1 }, { unique: true });

module.exports = mongoose.model("ParameterMaster", parameterMasterSchema);