const mongoose = require("mongoose");

const labOrderSchema = new mongoose.Schema(
  {
    accessionNo: {
      type: String,
      unique: true,
      required: true,
      index: true
    },
    patientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true,
      index: true
    },
    visitId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Visit',
      required: true,
      index: true
    },
    opdBillingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'OpdBilling',
      required: true,
      index: true
    },
    doctorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // Assuming doctors are stored in User model
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'collected', 'saved', 'authorized'],
      default: 'pending',
      index: true
    },
    orderDate: {
      type: Date,
      default: Date.now,
      required: true
    },
    // Additional metadata
    priority: {
      type: String,
      enum: ['normal', 'urgent', 'stat'],
      default: 'normal'
    },
    instructions: {
      type: String,
      maxlength: 1000
    },
    collectedAt: {
      type: Date
    },
    collectedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    savedAt: {
      type: Date
    },
    savedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    authorizedAt: {
      type: Date
    },
    authorizedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    // Cached patient info for quick access
    patientInfo: {
      name: String,
      uhid: String,
      age: String,
      gender: String,
      mobileNo: String
    },
    // Cached doctor info
    doctorInfo: {
      name: String,
      specialization: String
    }
  },
  { 
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Virtual for formatted accession display
labOrderSchema.virtual('formattedAccession').get(function() {
  return `ACC-${this.accessionNo}`;
});

// Virtual for status display
labOrderSchema.virtual('statusDisplay').get(function() {
  const statusMap = {
    pending: 'Pending Collection',
    collected: 'Sample Collected',
    saved: 'Results Saved',
    authorized: 'Authorized'
  };
  return statusMap[this.status] || this.status;
});

// Pre-save middleware to generate accession number
labOrderSchema.pre("save", async function (next) {
  if (!this.accessionNo) {
    const currentYear = new Date().getFullYear();
    const currentMonth = String(new Date().getMonth() + 1).padStart(2, "0");
    const currentDay = String(new Date().getDate()).padStart(2, "0");
    
    // Find the last lab order created today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const lastOrder = await this.constructor.findOne({
      createdAt: { $gte: today, $lt: tomorrow }
    }).sort({ createdAt: -1 });
    
    let sequenceNumber = 1;
    if (lastOrder && lastOrder.accessionNo) {
      const lastSequence = parseInt(lastOrder.accessionNo.slice(-4));
      if (!isNaN(lastSequence)) {
        sequenceNumber = lastSequence + 1;
      }
    }
    
    // Format: LAB{YYYYMMDD}{NNNN}
    this.accessionNo = `LAB${currentYear}${currentMonth}${currentDay}${String(sequenceNumber).padStart(4, '0')}`;
  }

  // Update timestamps based on status changes
  if (this.isModified('status')) {
    const now = new Date();
    switch (this.status) {
      case 'collected':
        if (!this.collectedAt) this.collectedAt = now;
        break;
      case 'saved':
        if (!this.savedAt) this.savedAt = now;
        break;
      case 'authorized':
        if (!this.authorizedAt) this.authorizedAt = now;
        break;
    }
  }

  next();
});

// Indexes for better performance
labOrderSchema.index({ accessionNo: 1 });
labOrderSchema.index({ patientId: 1, orderDate: -1 });
labOrderSchema.index({ status: 1, orderDate: -1 });
labOrderSchema.index({ orderDate: -1 });
labOrderSchema.index({ doctorId: 1 });
labOrderSchema.index({ visitId: 1 });

module.exports = mongoose.model("LabOrder", labOrderSchema);